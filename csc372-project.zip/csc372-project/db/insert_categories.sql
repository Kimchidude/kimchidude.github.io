INSERT OR IGNORE INTO rarities (name, priority) VALUES ('Secret Rare', 1);
INSERT OR IGNORE INTO rarities (name, priority) VALUES ('Ultimate Rare', 2);
INSERT OR IGNORE INTO rarities (name, priority) VALUES ('Ultra Rare', 3);
INSERT OR IGNORE INTO rarities (name, priority) VALUES ('Super Rare', 4);
INSERT OR IGNORE INTO rarities (name, priority) VALUES ('Rare', 5);
INSERT OR IGNORE INTO rarities (name, priority) VALUES ('Common', 6);
