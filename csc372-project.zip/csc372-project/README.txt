Milestone 4

Check db folder for sql files. Changed app.js to apply sql at npm start.
From index.html or localhost:3000, click Dark Magician to go to admin-products.html.
You can delete a card and restart server to see that I initialize with 3 cards on server start.